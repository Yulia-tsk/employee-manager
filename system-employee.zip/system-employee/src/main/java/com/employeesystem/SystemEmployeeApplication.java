package com.employeesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemEmployeeApplication.class, args);
	}

}
