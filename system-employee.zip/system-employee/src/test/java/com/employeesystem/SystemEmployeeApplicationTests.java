package com.employeesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
